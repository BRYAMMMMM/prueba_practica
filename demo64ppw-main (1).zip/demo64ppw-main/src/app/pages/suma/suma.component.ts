import { Component } from '@angular/core';

@Component({
  selector: 'app-suma',
  standalone: true,
  imports: [],
  templateUrl: './suma.component.html',
  styleUrl: './suma.component.scss'
})
export class SumaComponent {

}
