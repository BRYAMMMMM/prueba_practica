import { Component } from '@angular/core';

@Component({
  selector: 'app-resta',
  standalone: true,
  imports: [],
  templateUrl: './resta.component.html',
  styleUrl: './resta.component.scss'
})
export class RestaComponent {

}
