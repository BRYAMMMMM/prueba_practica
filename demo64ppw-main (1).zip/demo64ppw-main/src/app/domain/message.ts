export class Message {
    title!:string
    msg:string = ''
}